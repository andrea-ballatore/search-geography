- Based on Simon's data
- Amsterdam is not included between its value would be 10x higher than the other units.
- Only two areas grew by a tiny amount (2007-2017) GM0431 Oostzaan, GM0376 Blaricum. All other units declined.
- The following GMs show relatively high interest:

	> GM0392	Haarlem
	> GM0034	Almere
	> GM0406	Huizen
	> GM0402	Hilversum
	> GM0995	Lelystad
	> GM0417	Laren
	> GM0362	Amstelveen
	> GM0439	Purmerend