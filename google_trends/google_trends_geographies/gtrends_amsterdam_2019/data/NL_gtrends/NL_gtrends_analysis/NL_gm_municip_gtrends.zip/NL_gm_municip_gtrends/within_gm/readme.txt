- concept vs string is not that important, very similar results, so we just look at concepts.
- There is a general decline in relative interest world wide, and a general increase in the NL.

- 3 GMs grow both worldwide and in the NL:
	Edam-Volendam (+24%) GM0385;
	Oostzaan (+10%) GM0431;
	Blaricum (+1%) GM0376.

- Areas that show a loss in interest both worldwide and in the NL (20%-40% decline):
	Haarlemmerliede en Spaarnwoude - GM0393;
	Ouder-Amstel - GM0437;
	Haarlemmermeer - GM0394;
	Velsen - GM0453;
	Wormerland - GM0880.